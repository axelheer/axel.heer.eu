﻿using System;
using System.Diagnostics;
using System.Reflection;

namespace Heer.Composition.Aspects.Sample
{
    [AspectExport(Order = 100)]
    public class AuditAspect : Aspect
    {
        public override bool OnEnter(object target, MethodInfo info, params object[] args)
        {
            var enter = string.Concat(
                target.GetType().FullName,
                ".",
                info.Name,
                "(",
                string.Join(", ", args),
                ")");
            Trace.WriteLine(string.Format("AUDIT: {0}", enter));
            return true;
        }

        public override bool OnError(object target, MethodInfo info, Exception fail, params object[] args)
        {
            var error = string.Concat(
                target.GetType().FullName,
                ".",
                info.Name,
                " ---> ",
                fail);
            Trace.WriteLine(string.Format("AUDIT: {0}", error));
            return false;
        }

        public override object OnExit(object target, MethodInfo info, object result, params object[] args)
        {
            var exit = string.Concat(
                target.GetType().FullName,
                ".",
                info.Name,
                " ---> ",
                info.ReturnType != typeof(void)
                    ? result
                    : "<void>");
            Trace.WriteLine(string.Format("AUDIT: {0}", exit));
            return result;
        }
    }
}
