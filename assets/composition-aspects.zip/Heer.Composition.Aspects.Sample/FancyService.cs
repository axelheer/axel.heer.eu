﻿using System;
using System.ComponentModel.Composition;
using System.Diagnostics;

namespace Heer.Composition.Aspects.Sample
{
    [Export]
    [WithAspects]
    public class FancyService
    {
        [AspectImport(typeof(AuditAspect))]
        public virtual void DoSomething(string value)
        {
            Trace.WriteLine(string.Format("Doing something with {0}...", value));
        }

        [AspectImport(typeof(AuditAspect))]
        [AspectImport(typeof(HandleErrorAspect))]
        public virtual void FailSomehow()
        {
            throw new Exception("Fail!");
        }
    }
}
