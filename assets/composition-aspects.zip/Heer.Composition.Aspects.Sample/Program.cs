﻿using System;
using System.ComponentModel.Composition.Hosting;
using System.Diagnostics;

namespace Heer.Composition.Aspects.Sample
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Trace.Listeners.Clear();
            Trace.Listeners.Add(new TextWriterTraceListener(Console.Out));

            var catalog = new AssemblyCatalog(typeof(Program).Assembly);
            var provider = new WithAspectsExportProvider(catalog);

            using (var container = new CompositionContainer(provider))
            {
                provider.SourceProvider = container;

                var service = container.GetExportedValue<FancyService>();

                service.DoSomething("something");
                service.FailSomehow();
            }

            Console.ReadLine();
        }
    }
}
