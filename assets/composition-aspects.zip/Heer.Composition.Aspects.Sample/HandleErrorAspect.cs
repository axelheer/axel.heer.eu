﻿using System;
using System.Reflection;

namespace Heer.Composition.Aspects.Sample
{
    [AspectExport(Order = 1)]
    public class HandleErrorAspect : Aspect
    {
        public override bool OnError(object target, MethodInfo info, Exception fail, params object[] args)
        {
            return true; // muhaha!
        }
    }
}
