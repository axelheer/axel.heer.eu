﻿using System;

namespace Heer.Composition.Aspects
{
    /// <summary>
    /// Specifies that a method should be decorated with a specified aspect.
    /// </summary>
    [AttributeUsage(AttributeTargets.Method, AllowMultiple = true)]
    public sealed class AspectImportAttribute : Attribute
    {
        /// <summary>
        /// Gets the type of the aspect export to import.
        /// </summary>
        public Type ContractType { get; private set; }

        /// <summary>
        /// Imports the aspect with the contract derived from the given type.
        /// </summary>
        /// <param name="contractType">The type of the aspect export to import.</param>
        public AspectImportAttribute(Type contractType)
        {
            if (contractType == null)
                throw new ArgumentNullException("contractType");

            ContractType = contractType;
        }
    }
}
