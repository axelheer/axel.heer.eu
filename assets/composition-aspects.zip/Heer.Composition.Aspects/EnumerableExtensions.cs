﻿using System;
using System.Collections.Generic;

namespace Heer.Composition.Aspects
{
    internal static class EnumerableExtensions
    {
        public static IEnumerable<T> Flatten<T>(this T value, Func<T, T> inner)
            where T : class
        {
            while (value != null)
            {
                yield return value;
                value = inner(value);
            }
        }
    }
}
