﻿using System;
using System.ComponentModel.Composition;

namespace Heer.Composition.Aspects
{
    /// <summary>
    /// Marks an export to be decorated with aspects.
    /// </summary>
    [MetadataAttribute]
    [AttributeUsage(AttributeTargets.Class)]
    public sealed class WithAspectsAttribute : Attribute
    {
        /// <summary>
        /// True, if the type should be decorated with aspects; false, otherwise.
        /// </summary>
        public bool ExportWithAspects { get; private set; }

        /// <summary>
        /// Marks the export to be decorated with aspects or not.
        /// </summary>
        /// <param name="exportWithAspects">True, if the type should be decorated with aspects; false, otherwise.</param>
        public WithAspectsAttribute(bool exportWithAspects)
        {
            ExportWithAspects = exportWithAspects;
        }

        /// <summary>
        /// Marks the export to be decorated with aspects.
        /// </summary>
        public WithAspectsAttribute()
            : this(true)
        {
        }
    }
}
