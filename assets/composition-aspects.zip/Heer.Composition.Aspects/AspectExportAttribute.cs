﻿using System;
using System.ComponentModel.Composition;

namespace Heer.Composition.Aspects
{
    /// <summary>
    /// Specifies that a type provides a particular aspect export.
    /// </summary>
    [MetadataAttribute]
    [AttributeUsage(AttributeTargets.Class)]
    public sealed class AspectExportAttribute : ExportAttribute
    {
        /// <summary>
        /// The order of aspect invocation. Smaller values lead to earlier invocation.
        /// </summary>
        public int Order { get; set; }

        /// <summary>
        /// Exports the type under a contract derived from the given type.
        /// </summary>
        /// <param name="contractType">A type from which to derive the contract.</param>
        public AspectExportAttribute(Type contractType)
            : base(contractType)
        {
        }

        /// <summary>
        /// Exports the type under a contract derived from the type itself.
        /// </summary>
        public AspectExportAttribute()
            : base()
        {
        }
    }
}
