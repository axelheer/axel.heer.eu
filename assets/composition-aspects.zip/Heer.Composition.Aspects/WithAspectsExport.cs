﻿using Castle.DynamicProxy;
using Castle.DynamicProxy.Generators;
using System;
using System.ComponentModel.Composition.Primitives;
using System.Diagnostics.CodeAnalysis;
using System.IdentityModel.Services;
using System.Linq;
using System.Security.Permissions;

namespace Heer.Composition.Aspects
{
    /// <summary>
    /// Decorates an export with additional aspect exports.
    /// </summary>
    internal class WithAspectsExport : Export
    {
        private static readonly ProxyGenerator generator = new ProxyGenerator();

        [SuppressMessage("Microsoft.Performance", "CA1810:InitializeReferenceTypeStaticFieldsInline")]
        static WithAspectsExport()
        {
            AttributesToAvoidReplicating.Add(typeof(PrincipalPermissionAttribute));
            AttributesToAvoidReplicating.Add(typeof(ClaimsPrincipalPermissionAttribute));
        }

        private readonly Type contract;
        private readonly Export innerExport;
        private readonly Export[] exportAspects;

        public WithAspectsExport(Type contract, Export innerExport, params Export[] exportAspects)
        {
            this.contract = contract;
            this.innerExport = innerExport;
            this.exportAspects = exportAspects;
        }

        public override ExportDefinition Definition
        {
            get { return innerExport.Definition; }
        }

        protected override object GetExportedValueCore()
        {
            var aspectHosts = exportAspects.OrderBy(e => orderOfAspect(e))
                                           .Select(a => new AspectHost((Aspect)a.Value))
                                           .ToArray();
            if (contract.IsInterface)
            {
                return generator.CreateInterfaceProxyWithTarget(contract, innerExport.Value, aspectHosts);
            }
            else
            {
                return generator.CreateClassProxyWithTarget(contract, innerExport.Value, aspectHosts);
            }
        }

        private static int orderOfAspect(Export export)
        {
            var value = default(object);
            if (export.Metadata.TryGetValue("Order", out value))
                return (int)value;
            return 0;
        }
    }
}
