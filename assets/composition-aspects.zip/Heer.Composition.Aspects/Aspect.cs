﻿using System;
using System.Reflection;

namespace Heer.Composition.Aspects
{
    /// <summary>
    /// Represents the base class for aspects.
    /// </summary>
    public abstract class Aspect
    {
        /// <summary>
        /// Called before the actual method call.
        /// </summary>
        /// <param name="target">The object being called.</param>
        /// <param name="info">The method being called.</param>
        /// <param name="args">The method's arguments.</param>
        /// <returns>True, if the method should be called; false, otherwise.</returns>
        public virtual bool OnEnter(object target, MethodInfo info, params object[] args)
        {
            return true;
        }

        /// <summary>
        /// Called if the method call fails.
        /// </summary>
        /// <param name="target">The object being called.</param>
        /// <param name="info">The method being called.</param>
        /// <param name="fail">The failure itself.</param>
        /// <param name="args">The method's arguments.</param>
        /// <returns>True, if failure has been handled; false, otherwise.</returns>
        public virtual bool OnError(object target, MethodInfo info, Exception fail, params object[] args)
        {
            return false;
        }

        /// <summary>
        /// Called after the actual method call.
        /// </summary>
        /// <param name="target">The object being called.</param>
        /// <param name="info">The method being called.</param>
        /// <param name="result">The result of the call.</param>
        /// <param name="args">The method's arguments.</param>
        /// <returns>The final result of the call.</returns>
        public virtual object OnExit(object target, MethodInfo info, object result, params object[] args)
        {
            if (result == null && info.ReturnType != typeof(void) && info.ReturnType.IsValueType)
            {
                return Activator.CreateInstance(info.ReturnType);
            }
            return result;
        }
    }
}
