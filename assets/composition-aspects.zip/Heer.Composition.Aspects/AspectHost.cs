﻿using Castle.DynamicProxy;
using System;
using System.Linq;

namespace Heer.Composition.Aspects
{
    /// <summary>
    /// Hosts an aspect using Castle DynamicProxy.
    /// </summary>
    internal class AspectHost : IInterceptor
    {
        private readonly Aspect aspect;

        public AspectHost(Aspect aspect)
        {
            if (aspect == null)
                throw new ArgumentNullException("aspect");

            this.aspect = aspect;
        }

        public void Intercept(IInvocation invocation)
        {
            if (invocation == null)
                throw new ArgumentNullException("invocation");

            var target = invocation.InvocationTarget;
            var method = invocation.MethodInvocationTarget;
            var aspects = (AspectImportAttribute[])method.GetCustomAttributes(typeof(AspectImportAttribute), true);

            if (aspects.Any(m => m.ContractType.IsAssignableFrom(aspect.GetType())))
            {
                if (aspect.OnEnter(target, method, invocation.Arguments))
                {
                    try
                    {
                        invocation.Proceed();
                    }
                    catch (Exception ex)
                    {
                        if (!aspect.OnError(target, method, ex, invocation.Arguments))
                        {
                            throw;
                        }
                    }
                    invocation.ReturnValue = aspect.OnExit(target, method, invocation.ReturnValue, invocation.Arguments);
                }
            }
            else
            {
                invocation.Proceed();
            }
        }
    }
}
