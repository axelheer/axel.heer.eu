﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition.Hosting;
using System.ComponentModel.Composition.Primitives;
using System.Linq;

namespace Heer.Composition.Aspects
{
    /// <summary>
    /// Retrieves decorated exports from a catalog.
    /// </summary>
    public class WithAspectsExportProvider : CatalogExportProvider
    {
        private readonly WithAspectsCatalog aspects;

        /// <summary>
        /// Initializes a new provider with the given catalog.
        /// </summary>
        /// <param name="catalog">The catalog to use.</param>
        /// <param name="aspectsCatalog">The aspects catalog to use.</param>
        public WithAspectsExportProvider(ComposablePartCatalog catalog, WithAspectsCatalog aspectsCatalog)
            : base(catalog)
        {
            if (catalog == null)
                throw new ArgumentNullException("catalog");
            if (aspectsCatalog == null)
                throw new ArgumentNullException("aspectsCatalog");

            aspects = aspectsCatalog;
        }

        /// <summary>
        /// Initializes a new provider with the given catalog.
        /// </summary>
        /// <param name="catalog">The catalog to use.</param>
        public WithAspectsExportProvider(ComposablePartCatalog catalog)
            : base(catalog)
        {
            if (catalog == null)
                throw new ArgumentNullException("catalog");

            aspects = new WithAspectsCatalog(catalog);
        }

        /// <inheritdoc />
        protected override IEnumerable<Export> GetExportsCore(ImportDefinition definition, AtomicComposition atomicComposition)
        {
            var result = new List<Export>();

            foreach (var export in base.GetExportsCore(definition, atomicComposition))
            {
                if (WithAspectsCatalog.ExportHasAspects(export.Definition))
                {
                    var contract = aspects.ContractOfExport(export.Definition);
                    var exportAspects = aspects.AspectsOfExport(export.Definition)
                                               .Select(d => GetExports(d, atomicComposition).Single())
                                               .ToArray();
                    result.Add(new WithAspectsExport(contract, export, exportAspects));
                }
                else
                {
                    result.Add(export);
                }
            }

            return result;
        }
    }
}
