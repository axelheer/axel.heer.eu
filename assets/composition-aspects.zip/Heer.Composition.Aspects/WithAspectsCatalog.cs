﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.ComponentModel.Composition.Primitives;
using System.ComponentModel.Composition.ReflectionModel;
using System.Linq;
using System.Reflection;

namespace Heer.Composition.Aspects
{
    /// <summary>
    /// Searches and caches aspect exports for performance reasons.
    /// </summary>
    public class WithAspectsCatalog
    {
        private readonly Dictionary<string, Type> contracts;
        private readonly Dictionary<string, ImportDefinition[]> aspects;

        /// <summary>
        /// Creates a new aspect catalog.
        /// </summary>
        /// <param name="catalog">The catalog to search for aspects.</param>
        public WithAspectsCatalog(ComposablePartCatalog catalog)
        {
            if (catalog == null)
                throw new ArgumentNullException("catalog");

            var exports = catalog.Parts
                                 .SelectMany(p => p.ExportDefinitions)
                                 .Where(d => exportHasAspects(d))
                                 .GroupBy(d => identityOfExport(d))
                                 .Select(g => g.First())
                                 .ToList();

            contracts = exports.ToDictionary(d => identityOfExport(d),
                                             d => contractOfExport(d));
            aspects = exports.ToDictionary(d => identityOfExport(d),
                                           d => aspectsOfExport(d));
        }

        internal static bool ExportHasAspects(ExportDefinition definition)
        {
            if (definition == null)
                throw new ArgumentNullException("definition");
            return exportHasAspects(definition);
        }

        internal Type ContractOfExport(ExportDefinition definition)
        {
            if (definition == null)
                throw new ArgumentNullException("definition");
            return contracts[identityOfExport(definition)];
        }

        internal IEnumerable<ImportDefinition> AspectsOfExport(ExportDefinition definition)
        {
            if (definition == null)
                throw new ArgumentNullException("definition");
            return aspects[identityOfExport(definition)];
        }

        private static bool exportHasAspects(ExportDefinition definition)
        {
            var value = default(object);
            if (definition.Metadata.TryGetValue("ExportWithAspects", out value))
                return (bool)value;
            return false;
        }

        private static string identityOfExport(ExportDefinition definition)
        {
            var value = default(object);
            if (definition.Metadata.TryGetValue("ExportTypeIdentity", out value))
                return (string)value;
            throw new InvalidOperationException("Only exports with identity are supported yet.");
        }

        private static Type typeOfExport(ExportDefinition definition)
        {
            var member = ReflectionModelServices.GetExportingMember(definition);
            if (member.MemberType != MemberTypes.TypeInfo)
                throw new InvalidOperationException("Only type exports are supported yet.");
            return (Type)member.GetAccessors()[0];
        }

        private static Type contractOfExport(ExportDefinition definition)
        {
            var contract = typeOfExport(definition).Flatten(t => t.BaseType)
                                                   .Concat(typeOfExport(definition).GetInterfaces())
                                                   .Where(t => identityOfExport(definition)
                                                            == AttributedModelServices.GetTypeIdentity(t))
                                                   .Single();
            var invalid = contract.GetMethods()
                                  .Where(m => m.IsPublic
                                           && !m.IsStatic
                                           && !m.IsConstructor
                                           && (!m.IsVirtual || m.IsFinal)
                                           && m.DeclaringType != typeof(object))
                                  .ToList();
            if (invalid.Any())
            {
                var message = string.Concat(
                    "The following members of Type '",
                    contract.AssemblyQualifiedName,
                    "' have aspects but are not virtual: '",
                    string.Join("', '", invalid.Select(m => m.Name)),
                    "'. Thus, the proxy being generated may not work as expected.");
                throw new InvalidOperationException(message);
            }
            return contract;
        }

        private static ImportDefinition[] aspectsOfExport(ExportDefinition definition)
        {
            return typeOfExport(definition).GetMethods()
                                           .SelectMany(m => m.GetCustomAttributes(typeof(AspectImportAttribute), true))
                                           .Cast<AspectImportAttribute>()
                                           .Select(a => a.ContractType)
                                           .Distinct()
                                           .Select(t => new ContractBasedImportDefinition(
                                                        AttributedModelServices.GetContractName(t),
                                                        AttributedModelServices.GetTypeIdentity(t),
                                                        null,
                                                        ImportCardinality.ExactlyOne,
                                                        false,
                                                        true,
                                                        CreationPolicy.Any))
                                           .Cast<ImportDefinition>()
                                           .ToArray();
        }
    }
}
