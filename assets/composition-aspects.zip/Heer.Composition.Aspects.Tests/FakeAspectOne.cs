﻿using System;
using System.Reflection;

namespace Heer.Composition.Aspects.Tests
{
    [AspectExport(Order = 1)]
    public class FakeAspectOne : Aspect
    {
        public bool OnEnterCalled { get; set; }
        public bool OnEnterResult { get; set; }

        public override bool OnEnter(object target, MethodInfo info, params object[] args)
        {
            OnEnterCalled = true;
            return OnEnterResult;
        }

        public bool OnErrorCalled { get; set; }
        public bool OnErrorResult { get; set; }

        public override bool OnError(object target, MethodInfo info, Exception fail, params object[] args)
        {
            OnErrorCalled = true;
            return OnErrorResult;
        }

        public bool OnExitCalled { get; set; }
        public object OnExitResult { get; set; }

        public override object OnExit(object target, MethodInfo info, object result, params object[] args)
        {
            OnExitCalled = true;
            return OnExitResult;
        }
    }
}
