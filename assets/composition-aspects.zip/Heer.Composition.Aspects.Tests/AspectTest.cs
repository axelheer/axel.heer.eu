﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.ComponentModel.Composition.Hosting;

namespace Heer.Composition.Aspects.Tests
{
    [TestClass]
    public class AspectTest
    {
        private CompositionContainer container;

        private FakeAspectOne aspectOne;
        private FakeAspectTwo aspectTwo;

        private FakeService service;

        [TestInitialize]
        public void Initialize()
        {
            var catalog = new AssemblyCatalog(typeof(AspectTest).Assembly);
            var provider = new WithAspectsExportProvider(catalog);

            container = new CompositionContainer(provider);
            provider.SourceProvider = container;

            service = container.GetExportedValue<FakeService>();
            aspectOne = container.GetExportedValue<FakeAspectOne>();
            aspectTwo = container.GetExportedValue<FakeAspectTwo>();
        }

        [TestCleanup]
        public void Cleanup()
        {
            container.Dispose();
        }

        [TestMethod]
        public void BothAspectsShouldBeCalled()
        {
            aspectOne.OnEnterResult = true;
            aspectTwo.OnEnterResult = true;

            service.DoSomething(null);

            Assert.IsTrue(aspectOne.OnEnterCalled);
            Assert.IsTrue(aspectTwo.OnEnterCalled);
        }

        [TestMethod]
        public void AspectOneShouldCancelCall()
        {
            aspectOne.OnEnterResult = false;

            service.DoSomething(null);

            Assert.IsTrue(aspectOne.OnEnterCalled);
            Assert.IsFalse(aspectTwo.OnEnterCalled);
        }

        [TestMethod]
        public void AspectTwoShouldHandleError()
        {
            aspectOne.OnEnterResult = true;
            aspectTwo.OnEnterResult = true;
            aspectTwo.OnErrorResult = true;

            service.FailSomehow();

            Assert.IsTrue(aspectOne.OnEnterCalled);
            Assert.IsTrue(aspectTwo.OnErrorCalled);
        }
    }
}
