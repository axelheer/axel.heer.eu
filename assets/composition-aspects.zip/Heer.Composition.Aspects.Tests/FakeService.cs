﻿using System;
using System.ComponentModel.Composition;

namespace Heer.Composition.Aspects.Tests
{
    [Export]
    [WithAspects]
    public class FakeService
    {
        [AspectImport(typeof(FakeAspectOne))]
        [AspectImport(typeof(FakeAspectTwo))]
        public virtual string DoSomething(string value)
        {
            return value;
        }

        [AspectImport(typeof(FakeAspectOne))]
        [AspectImport(typeof(FakeAspectTwo))]
        public virtual string FailSomehow()
        {
            throw new Exception();
        }
    }
}
