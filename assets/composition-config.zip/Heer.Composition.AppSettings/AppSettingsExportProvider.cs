﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.Composition.Hosting;
using System.ComponentModel.Composition.Primitives;
using System.ComponentModel.Composition.ReflectionModel;
using System.Configuration;
using System.Globalization;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;

namespace Heer.Composition.AppSettings
{
    /// <summary>
    /// Retrieves configuration values from <c>AppSettings</c> as exports.
    /// </summary>
    public class AppSettingsExportProvider : ExportProvider
    {
        private readonly Regex pattern = new Regex(@"^appSettings:(?<Key>.*)$");

        /// <inheritdoc />
        protected override IEnumerable<Export> GetExportsCore(ImportDefinition definition, AtomicComposition atomicComposition)
        {
            if (definition == null)
                throw new ArgumentNullException("definition");

            var match = pattern.Match(definition.ContractName);

            if (match.Success)
            {
                var key = match.Groups["Key"].Value;
                var type = typeOfImport(definition);
                var converter = TypeDescriptor.GetConverter(type);

                return new[]
                {
                    new Export(definition.ContractName, () =>
                        converter.ConvertFromInvariantString(ConfigurationManager.AppSettings[key]))
                };
            }

            return new Export[0];
        }

        private static Type typeOfImport(ImportDefinition definition)
        {
            if (ReflectionModelServices.IsImportingParameter(definition))
            {
                var param = ReflectionModelServices.GetImportingParameter(definition);
                return param.Value.ParameterType;
            }
            else
            {
                var member = ReflectionModelServices.GetImportingMember(definition);
                switch (member.MemberType)
                {
                    case MemberTypes.Property:
                        return member.GetAccessors()
                                     .Cast<MethodInfo>()
                                     .SelectMany(m => m.GetParameters())
                                     .Select(p => p.ParameterType)
                                     .Single();
                    default:
                        throw new InvalidOperationException("Member type " + member.MemberType + " is not supported yet.");
                }
            }
        }
    }
}
