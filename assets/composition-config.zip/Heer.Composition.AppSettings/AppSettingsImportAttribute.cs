﻿using System;
using System.ComponentModel.Composition;

namespace Heer.Composition.AppSettings
{
    /// <summary>
    /// Specifies that a property or parameter should be loaded from <c>AppSettings</c>.
    /// </summary>
    [AttributeUsage(AttributeTargets.Parameter | AttributeTargets.Property)]
    public sealed class AppSettingsImportAttribute : ImportAttribute
    {
        /// <summary>
        /// Imports the specified target's value from <c>AppSettings</c>.
        /// </summary>
        /// <param name="contractName">The <c>AppSettings</c> key to use.</param>
        public AppSettingsImportAttribute(string contractName)
            : base("appSettings:" + contractName)
        {
            if (string.IsNullOrEmpty(contractName))
                throw new ArgumentNullException("contractName");
        }
    }
}
