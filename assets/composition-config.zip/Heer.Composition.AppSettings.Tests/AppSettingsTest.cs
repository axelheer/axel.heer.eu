﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.ComponentModel.Composition.Hosting;

namespace Heer.Composition.AppSettings.Tests
{
    [TestClass]
    public class AppSettingsTest
    {
        private CompositionContainer container;

        [TestInitialize]
        public void Initialize()
        {
            var catalog = new AssemblyCatalog(typeof(AppSettingsTest).Assembly);
            container = new CompositionContainer(catalog, new AppSettingsExportProvider());
        }

        [TestCleanup]
        public void Cleanup()
        {
            container.Dispose();
        }

        [TestMethod]
        public void ProviderShouldExportSomeSettingAsInt32()
        {
            var service = container.GetExportedValue<FakeService>();

            Assert.AreEqual(1138, service.SomeSetting);
        }

        [TestMethod]
        public void ProviderShouldExportOtherSettingAsSingle()
        {
            var service = container.GetExportedValue<FakeService>();

            Assert.AreEqual(3.14f, service.OtherSetting);
        }

        [TestMethod]
        public void ProviderShouldExportSwitchSettingAsBoolean()
        {
            var service = container.GetExportedValue<FakeService>();

            Assert.AreEqual(true, service.SwitchSetting);
        }
    }
}
