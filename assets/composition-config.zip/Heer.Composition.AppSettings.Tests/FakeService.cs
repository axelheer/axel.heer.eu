﻿using System.ComponentModel.Composition;

namespace Heer.Composition.AppSettings.Tests
{
    [Export]
    public class FakeService
    {
        [AppSettingsImport("someSetting")]
        public int SomeSetting { get; set; }

        [AppSettingsImport("otherSetting")]
        public float OtherSetting { get; set; }

        public bool SwitchSetting { get; private set; }

        [ImportingConstructor]
        public FakeService([AppSettingsImport("switchSetting")] bool switchSetting)
        {
            SwitchSetting = switchSetting;
        }
    }
}
