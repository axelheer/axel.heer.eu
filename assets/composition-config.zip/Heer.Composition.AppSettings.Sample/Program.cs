﻿using System;
using System.ComponentModel.Composition.Hosting;

namespace Heer.Composition.AppSettings.Sample
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var catalog = new AssemblyCatalog(typeof(Program).Assembly);
            var provider = new AppSettingsExportProvider();

            using (var container = new CompositionContainer(catalog, provider))
            {
                var service = container.GetExportedValue<FancyService>();

                Console.WriteLine("SomeSetting: {0}", service.SomeSetting);
                Console.WriteLine("OtherSetting: {0}", service.OtherSetting);
                Console.WriteLine("SwitchSetting: {0}", service.SwitchSetting);
            }

            Console.ReadLine();
        }
    }
}
