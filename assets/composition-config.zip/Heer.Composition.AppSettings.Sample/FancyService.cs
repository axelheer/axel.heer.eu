﻿using System.ComponentModel.Composition;

namespace Heer.Composition.AppSettings.Sample
{
    [Export]
    public class FancyService
    {
        [AppSettingsImport("someSetting")]
        public int SomeSetting { get; set; }

        [AppSettingsImport("otherSetting")]
        public float OtherSetting { get; set; }

        public bool SwitchSetting { get; private set; }

        [ImportingConstructor]
        public FancyService([AppSettingsImport("switchSetting")] bool switchSetting)
        {
            SwitchSetting = switchSetting;
        }
    }
}
